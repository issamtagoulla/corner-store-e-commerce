package com.youcode.enums;

public enum StarsAttributeName {
	STAR_1,
	STAR_2,
	STAR_3,
	STAR_4,
	STAR_5
}
