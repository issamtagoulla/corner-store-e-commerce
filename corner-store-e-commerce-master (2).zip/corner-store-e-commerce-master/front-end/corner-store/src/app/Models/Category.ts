export class Category {
  createdAt: String;
  id: number;
  label: String;
  sub_categories: Array<Category>;
  updatedAt: String;

  constructor() {}
    
}
