export class Jwt{
    jwt : string;
}