import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-week-deal',
  templateUrl: './week-deal.component.html',
  styleUrls: ['./week-deal.component.scss']
})
export class WeekDealComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
